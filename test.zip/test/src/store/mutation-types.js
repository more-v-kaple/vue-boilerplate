export const SET_AUTH = 'set_auth';
export const PURGE_AUTH = 'purge_auth';
export const SET_ERROR = 'set_error';
