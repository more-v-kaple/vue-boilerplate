import { login } from '@/services/repository';
import JwtService from '@/services/jwt.service';
import { LOGIN, LOGOUT } from '../action-types';
import { SET_AUTH, PURGE_AUTH, SET_ERROR } from '../mutation-types';

const state = {
  errors: null,
  user: {},
  isAuthenticated: !!JwtService.getToken(),
};

const getters = {
  currentUser(state) {
    return state.user;
  },
  isAuthenticated(state) {
    return state.isAuthenticated;
  },
};

const actions = {
  async [LOGIN](context, credentials) {
    try {
      const user = await login(credentials);
      context.commit(SET_AUTH, user);
      console.log('success');
    } catch (e) {
      console.log('error');
      context.commit(SET_ERROR, e);
    }
  },
  [LOGOUT](context) {
    context.commit(PURGE_AUTH);
  },
};

const mutations = {
  [SET_ERROR](state, error) {
    state.errors = error;
  },
  [SET_AUTH](state, user) {
    state.isAuthenticated = true;
    state.user = user;
    state.errors = {};
    JwtService.saveToken(state.user.token);
  },
  [PURGE_AUTH](state) {
    state.isAuthenticated = false;
    state.user = {};
    state.errors = {};
    JwtService.destroyToken();
  },
};

export default {
  state,
  actions,
  mutations,
  getters,
};
