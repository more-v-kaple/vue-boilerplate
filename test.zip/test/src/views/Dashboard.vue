<template>
  <div class="container">
    <h1>{{ $t('dashboard') }}</h1>
  </div>
</template>
