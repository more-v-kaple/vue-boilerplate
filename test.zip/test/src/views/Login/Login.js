import { LOGIN } from '@/store/action-types';

export default {
  name: 'Login',
  data() {
    return {
      valid: false,
      e1: false,
      password: '',
      passwordRules: [v => !!v || this.$t('Password is required')],
      userName: '',
      userNameRules: [v => !!v || this.$t('Username is required')],
    };
  },
  computed: {
    isAuthenticated() {
      return this.$store.getters.isAuthenticated;
    },
    showWarning() {
      return this.password && this.userName && this.$store.getters.errors;
    },
  },
  methods: {
    submit() {
      if (this.$refs.form.validate()) {
        const { userName, password } = this;
        this.$store.dispatch(LOGIN, { userName, password });
      }
    },
    clear() {
      this.$refs.form.reset();
    },
  },
  watch: {
    isAuthenticated(val) {
      if (val) {
        this.$router.push({ name: 'dashboard', params: { userName: this.userName } });
      }
    },
  },
};
